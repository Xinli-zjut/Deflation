function DFSJ2=Dfsj2(x,m,n,R,d)
% The Jacobian of the function of the 2nd deflation
%  
    x1 = x(1:n); x2 = x(n+1:2*n);    % extract vectors from x
    x3 = x(2*n+1:3*n); x4 = x(3*n+1:4*n);
    J1 = Jf(x1);    % the 1st Jacobian
    J2 = Jf2(x1,x2);  % the 2nd Jacobian
    J3 = Jf3(x1,x2,x3);  % the 3rd Jacobian
    J4 = Jf2(x1,x3);

    DFSJ2 = [J1, zeros(m,3*n);
         J2, J1, zeros(m, 2*n);
         zeros(size(R{1},1),n), R{1}, zeros(size(R{1},1),2*n);
         Jf2(x1,x3), zeros(m,n), J1, zeros(m,n);
         J3+Jf2(x1,x4), J4, J2, J1;
         zeros(size(R{1},1),3*n), R{1};
         zeros(size(R{2},1), 2*n), R{2}];
end