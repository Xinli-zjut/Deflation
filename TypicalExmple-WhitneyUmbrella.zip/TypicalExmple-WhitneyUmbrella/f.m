% the Whitney umbrella

function F=f(x)
F=x(1)^2-x(2)^2*x(3);
end