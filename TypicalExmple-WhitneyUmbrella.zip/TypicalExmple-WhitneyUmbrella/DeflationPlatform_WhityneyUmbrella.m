
%% The computation of the first 4 numbers of the deflation sequence of the Whitney umbrella
% We denote them by: (n0,n1,n2,n3)=(nulld0,nulld1,nulld2,nulld3)
% By Xin Li-2023/10/18
clear
clc
tic
%% Step 0
x0=[5;5;1];  % input a known solution
ff = f(x0);  % verify the known solution
val=norm(ff); 
J0 = Jf(x0);  % the Jacobian at the known solution
m= size(J0,1); n = size(J0,2);             % size of the system
r0=rank(J0);
nulld0=n-r0; % the number n0


%% Step 1

R1 = rand(n-r0,n);  d1 = rand(n-r0,1);      % get random R and d
y0 = [R1;J0]\[d1;zeros(m,1)]; % get y0 such that J0*y0 = 0 and R*y0 = d;
DF1 = Dfs1([x0;y0], m, n, R1, d1);  % valuation of the first deflation mapping
valdf1=norm(DF1);
DJ1 = Dfsj1([x0;y0],m, n, R1, d1); % the Jacobian of the deflation mapping at [x0;y0]
r1=rank(DJ1);
size(DJ1);
DJ1r=size(DJ1,1);DJ1c=size(DJ1,2);
nulld1=2*n-r1; % the number n1

%% Step 2

R2 = rand(nulld1,2*n); d2 = rand(nulld1,1);
z0 = [R2; DJ1]\[d2; zeros(DJ1r,1)];        % get z0 s.t. M*z0 = 0 and S*z0 = dd
%~norm([R2;DJ1]*z0-[d2; zeros(DJ1r,1)]);      % verify z0
u0 = z0(1:n); v0 = z0(n+1:end);
DF2=Dfs2([x0;y0;u0;v0],  m,  n,  {R1,R2}, {d1, d2});
valdf2=norm(DF2);
DJ2= Dfsj2([x0;y0;u0;v0],  m,  n,  {R1,R2}, {d1, d2});  % Jacobian of the second deflation mapping
r2=rank(DJ2);
size(DJ2);
DJ2r=size(DJ2,1); DJ2c=size(DJ2,2);
nulld2=4*n-r2;   % the number n2
%%  Step 3

R3=rand(nulld2,4*n); d3 = rand(nulld2,1);
zz0 = [R3; DJ2]\[d3; zeros(DJ2r,1)];       
%~norm([R3;DJ2]*zz0-[d3; zeros(DJ2r,1)]);      % verify zz0
a0 = zz0(1:n); b0 = zz0(n+1:2*n);c0 = zz0(2*n+1:3*n); d0 = zz0(3*n+1:4*n);
DF3 = Dfs3([x0;y0;u0;v0;a0;b0;c0;d0],  m, n, {R1,R2,R3}, {d1, d2,d3});  % valuation of the 3rd deflation mapping
valdf3=norm(DF3);
DJ3=Dfsj3([x0;y0;u0;v0;a0;b0;c0;d0],  m, n,  {R1,R2,R3}, {d1, d2,d3});  %Jacobian of 3rd deflation
size(DJ3);
r3=rank(DJ3);
nulld3=8*n-r3; % the number n3

%%
time=toc;








