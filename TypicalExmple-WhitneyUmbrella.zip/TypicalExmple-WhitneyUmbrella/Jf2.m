% The partial Jacobian: J(J(x)y,x)

function JF2=Jf2(x,y)
JF2=[2*y(1),-2*x(3)*y(2)-2*x(2)*y(3),-2*x(2)*y(2)];
end