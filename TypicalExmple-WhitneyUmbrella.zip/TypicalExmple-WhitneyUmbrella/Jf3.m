% The partial Jacobian: J(J(J(x)y,x)z,x)

function JF3=Jf3(x,y,z)
JF3=[0,-2*y(3)*z(2)-2*y(2)*z(3),-2*y(2)*z(2)];
end