function DFS3=Dfs3(x,m,n,R,d)
% 3nd round deflation function 

    x1 = x(1:n); 
    x2 = x(n+1:2*n);    
    x3 = x(2*n+1:3*n);
    x4 = x(3*n+1:4*n);
    x5 = x(4*n+1:5*n); 
    x6 = x(5*n+1:6*n);    % extract vectors from x
    x7 = x(6*n+1:7*n);
    x8 = x(7*n+1:8*n);

   J = Jf(x1);                    % the 1st Jacobian
   J4=Jf2(x1,x3);

 DFS3 = [f(x1); %-------------------function 1
         J*x2;            %-------------------function 2
         R{1}*x2-d{1};    %-------------------function 3
         J*x3;            %-------------------function 4
         Jf2(x1, x2)*x3+J*x4; %---function 5
         R{1}*x4;     %-----------------------function 6
         R{2}*[x3;x4]-d{2}; %-----------------function 7
         J*x5;    %--------------------------function 8
        Jf2(x1, x2)*x5+J*x6; %---function 9
        R{1}*x6;     %-----------------------function 10
       Jf2(x1, x3)*x5+J*x7; %---function 11
       Jf3(x1, x2, x3)*x5+Jf2(x1, x4)*x5+J4*x6+Jf2(x1, x2)*x7+J*x8;  %----function 12
         R{1}*x8;     %-----------------------function 13
         R{2}*[x7;x8]; %----------------------function 14
         R{3}*[x5;x6;x7;x8]-d{3}; %-----------function 15
];
end