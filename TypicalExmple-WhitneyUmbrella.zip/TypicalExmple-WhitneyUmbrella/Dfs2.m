% The function of the 2nd deflation

function DFS2=Dfs2(x,m,n,R,d)

    x1 = x(1:n); x2 = x(n+1:2*n);    % extract vectors from x
    x3 = x(2*n+1:3*n); x4 = x(3*n+1:4*n);
    J = Jf(x1);    % the 1st Jacobian

    DFS2=[f(x1);
         J*x2;
         R{1}*x2-d{1};
         J*x3;
         Jf2(x1, x2)*x3+J*x4;
         R{1}*x4;
         R{2}*[x3;x4]-d{2}];
end