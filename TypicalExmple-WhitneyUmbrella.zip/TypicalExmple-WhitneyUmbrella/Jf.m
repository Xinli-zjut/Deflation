% The Jacobian of Whitney umbrella: J(x)
function JF=Jf(x)
JF=[2*x(1), -2*x(2)*x(3),-x(2)^2];
end