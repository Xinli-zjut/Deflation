% The function of the 1st deflation

function DFS1=Dfs1(x,m,n,R,d)  

x1=x(1:n);
x2=x(n+1:2*n);

DFS1=[f(x1);
    Jf(x1)*x2;
    R*x2-d];
end