% The Jacobian of the function of the 3nd deflation

function DFSJ3=Dfsj3(x,m,n,R,d)
    x1 = x(1:n); 
    x2 = x(n+1:2*n);    
    x3 = x(2*n+1:3*n);
    x4 = x(3*n+1:4*n);
    x5 = x(4*n+1:5*n); 
    x6 = x(5*n+1:6*n);    % extract vectors from x
    x7 = x(6*n+1:7*n);
    x8 = x(7*n+1:8*n);


    J1 = Jf(x1);          % the 1st Jacobian
    J2 = Jf2(x1,x2);      % the 2nd Jacobian
    J3 = Jf3(x1,x2,x3);   % the 3rd Jacobian
    J4 = Jf2(x1,x3);
    J5 = Jf2(x1,x5);      % the Jacobian J*x5 w.r.t x1
    J25= Jf3(x1,x2,x5);   % block 9: the Jacobian of (Jacobian of J*x2 w.r.t. x1)*x5 w.r.t. x1 
    J252=Jf2(x1,x5);      %  block 9
    J16 = Jf2(x1,x6);     %  block 9: the Jacobian of J*x6 w.r.t. x1     % block 12:4
    J35= Jf3(x1,x3,x5);   % block 11: the Jacobian of (Jacobian of J*x3 w.r.t. x1)*x5 w.r.t. x1 
    J353=Jf2(x1,x5);      %  block 11
    J17 = Jf2(x1,x7);     %  block 11: the Jacobian of J*x7 w.r.t. x1
    J13 = Jf2(x1,x3);     %  block 11: the Jacobian of J*x3 w.r.t. x1
   
   J14=Jf2(x1,x4);        %  block 12: the Jacobian of J*x4 w.r.t. x1
   J45= Jf3(x1,x4,x5);    %  block 12:
   J27= Jf3(x1,x2,x7);    %  block 12:
   J18=Jf2(x1,x8);        %  block 12:
   J272=Jf2(x1,x7);   %  block 12
   J454=Jf2(x1,x5);   %  block 12
   J232=Jf2(x1,x3);   %  block 12
   J63=Jf3(x1,x6,x3); %  block 12:1
   J35=Jf3(x1,x3,x5); %  block 12:2
   J25=Jf3(x1,x2,x5); %  block 12:3
 

 DFSJ3 = [J1, zeros(m,7*n); ...       %-------------------------------------subJacobian block 1
         J2, J1, zeros(m, 6*n);     %-------------------------------------subJacobian block 2
         zeros(size(R{1},1),n), R{1}, zeros(size(R{1},1),6*n);   %--------subJacobian block 3
         Jf2(x1,x3), zeros(m,n), J1, zeros(m,5*n); %--------subJacobian block 4
         J3+Jf2(x1,x4), J4, J2, J1, zeros(m,4*n);    %--------subJacobian block 5
         zeros(size(R{1},1),3*n), R{1}, zeros(size(R{1},1),4*n);           %--------subJacobian block 6  
         zeros(size(R{2},1), 2*n), R{2}, zeros(size(R{2},1),4*n);         %---------subJacobian block 7  
         J5, zeros(m, 3*n), J1, zeros(m, 3*n);                %---------subJacobian block 8  
         J25+J16,J252,zeros(m,2*n),J2,J1,zeros(m,2*n);        %---------subJacobian block 9
  zeros(size(R{1},1),5*n),R{1},zeros(size(R{1},1),2*n);        %----------subJacobian block 10
J35+J17,zeros(m,n),J353,zeros(m,n),J13,zeros(m,n),J1,zeros(m,n); %--subJacobian block 11

  J45+J63+J27+J18,J35+J272,J25+J16,J454,J3+J14,J232,J2,J1; % need the subJacobian block 12                                                    
                                 
zeros(size(R{1},1),7*n), R{1};  %----------------------------------------subJacobian block 13
zeros(size(R{2},1),6*n), R{2};  %----------------------------------------subJacobian block 14
zeros(size(R{3},1),4*n), R{3}];  %----------------------------------------subJacobian block 15

end