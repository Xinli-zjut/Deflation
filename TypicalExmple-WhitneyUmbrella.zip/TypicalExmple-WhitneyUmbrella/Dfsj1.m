
% The Jacobian of the function of the 1st deflation

function DFSJ1=Dfsj1(x,m,n,R,d)

x1=x(1:n); x2=x(n+1:2*n);

J1=Jf(x1); J2=Jf2(x1,x2);

DFSJ1=[J1, zeros(m,n);
       J2, J1;
       zeros(size(R,1),n), R];
end